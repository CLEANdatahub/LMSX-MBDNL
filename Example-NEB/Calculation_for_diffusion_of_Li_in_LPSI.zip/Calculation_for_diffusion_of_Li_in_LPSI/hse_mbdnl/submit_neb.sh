#!/bin/bash -l
#SBATCH -N 4
#SBATCH --ntasks-per-node=28
#SBATCH --mem-per-cpu=4GB
#SBATCH --time=48:00:00
#SBATCH -p batch
#SBATCH -J mig

module load toolchain/intel
#source /home/users/sbanerjee/neb/venv/venv/bin/activate
PATH="/mnt/irisgpfs/users/sbanerjee/phonon_calc/py38/bin:${PATH}"
export PATH
#source /home/users/sbanerjee/MBD-test/venv/bin/activate
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export MKL_DYNAMIC="FALSE"
#import aimsChain
#import scipy
#import numpy
ulimit -s unlimited

aims=/mnt/irisgpfs/projects/tcp/software/bin/aims.211010.scalapack.mpi.x
#export PYTHONPATH=$PYTHONPATH:/mnt/irisgpfs/projects/tcp/software/aims/src/aimsChain
export PYTHONPATH=$PYTHONPATH:/mnt/irisgpfs/users/sbanerjee/phonon_calc/py38/bin
#export PYTHONPATH=$PYTHONPATH:/usr/bin/python2.7
export PATH=$PATH:/mnt/irisgpfs/users/sbanerjee/phonon_calc/py38/lib64/python3.6/site-packages/aimsChain/tools
#export PATH=$PATH:/mnt/irisgpfs/projects/tcp/software/aims/src/aimsChain/tools 
#export PATH=$PATH:/home/users/sbanerjee/neb/lyc_mbd_nl/neb_run/run/run_2
runchain.py

