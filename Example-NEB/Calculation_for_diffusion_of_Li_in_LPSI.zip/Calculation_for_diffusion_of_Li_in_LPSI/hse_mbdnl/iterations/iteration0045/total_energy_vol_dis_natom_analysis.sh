find . -name '*.out' > all_out_files.dat
#find . -name 'lps_mbd.out' > all_out_files.dat
for i in $(cat all_out_files.dat)

do
var1=$(grep "Total energy of the DFT / Hartree-Fock s.c.f. calculation" ${i} | tail | awk '{print $2}' FS=':' | awk '{print $1}')
#print(${var1})
var2=$(grep "Unit cell volume" ${i} | tail -1 | awk '{print $2}' FS=':' | awk '{print $1}')
var3=$(grep "vdW energy correction" ${i} | tail -1 | awk '{print $2}' FS=':' | awk '{print $3}')
var4=$(grep "Number of atoms            " ${i} | tail -1 | awk '{print $2}' FS=':')
echo "FreeEng in eV" ${var1} ${var2} ${var4} ${var3} $i >> energy_vol_dis_natom.txt
done

